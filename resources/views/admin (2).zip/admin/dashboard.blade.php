<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Family Aquarium</title>
    <style>
        /* Container utama */
        .dashboard-container {
            display: flex;
            background-color: #f4f4f4;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background-color: #2c2c2c;
            color: #fff;
            padding: 20px;
        }

        .brand {
            color: #28a745;
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .menu {
            list-style: none;
            padding: 0;
        }

        .menu-item {
            color: #ffffff;
            padding: 10px;
            display: flex;
            align-items: center;
            cursor: pointer;
            transition: background 0.3s;
        }

        .menu-item.active, .menu-item:hover {
            background-color: #28a745;
        }

        /* Icon dalam menu sidebar */
        .menu-item i {
            margin-right: 10px;
        }

        /* Bagian utama konten */
        .content {
            flex: 1;
            padding: 20px;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            font-size: 24px;
            margin: 0;
        }

        .search {
            position: relative;
        }

        .search input {
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .search-btn {
            position: absolute;
            right: 5px;
            top: 5px;
            background: none;
            border: none;
            cursor: pointer;
        }

        .user-info {
            display: flex;
            align-items: center;
            color: #333;
        }

        /* Grid layout untuk konten utama */
        .main-content {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr;
            gap: 20px;
            margin-top: 20px;
        }

        /* Komponen dalam konten utama */
        .sales-progress, .products, .shipment-schedule, .last-orders {
            background-color: #e6e6e6;
            padding: 20px;
            border-radius: 8px;
        }

        h2 {
            font-size: 18px;
            margin-bottom: 10px;
        }

        /* Tabel */
        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .view-all {
            display: block;
            text-align: center;
            margin-top: 10px;
            text-decoration: none;
            color: #28a745;
        }

        .view-all:hover {
            color: #218838;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <h2 class="brand">FAMILY AQUARIUM</h2>
            <ul class="menu">
                <li class="menu-item active"><i class="fas fa-tachometer-alt"></i> Dashboard</li>
                <li class="menu-item"><i class="fas fa-box"></i><a href="{{ route('admin.products') }}"> Products</a></li>
                <li class="menu-item"><i class="fas fa-chart-bar"></i><a href="{{ route('admin.delivery-schedules') }}"> Jadwal Pengantaran</a></li>
                <li class="menu-item"><i class="fas fa-receipt"></i> Transactions</li>
                <li class="menu-item"><i class="fas fa-users"></i> Customers</li>
                <li class="menu-item"><i class="fas fa-water"></i><a href="{{ route('admin.water_quality.index') }}"> Monitoring Air</a></li>
                <li class="menu-item"><i class="fas fa-file-alt"></i><a href="{{ route('admin.rekappenjualans.index') }}"> Rekap</a></li>
                <li class="menu-item">
                    <i class="fas fa-sign-out-alt"></i>
                    <form method="POST" action="{{ route('logout') }}" style="display:inline; margin-left: 8px;">
                        @csrf
                        <button type="submit" style="background: none; border: none; color: white; cursor: pointer;">LOGOUT</button>
                    </form>
                </li>
                
            </ul>
            
        </aside>
        <main class="content">
            <header class="header">
                <h1>DASHBOARD</h1>
                <div class="search">
                    <input type="text" placeholder="Search">
                    <button class="search-btn">🔍</button>
                </div>
                <div class="user-info">
                    <i class="icon-bell"></i> OWNER
                </div>
            </header>
            <section class="main-content">
                <div class="sales-progress">
                    <h2>Perkembangan Penjualan</h2>
                    <canvas id="salesChart" width="400" height="200"></canvas>
                </div>
                
                <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                <script>
                    const ctx = document.getElementById('salesChart').getContext('2d');
                    const salesChart = new Chart(ctx, {
                        type: 'bar',
                        data: {
                            labels: ['Oktober', 'November', 'Desember'],
                            datasets: [{
                                label: 'Jumlah Penjualan',
                                data: [10, 5, 15], // Ganti dengan data Anda
                                backgroundColor: [
                                    'rgba(75, 192, 192, 0.7)',
                                    'rgba(255, 99, 132, 0.7)',
                                    'rgba(54, 162, 235, 0.7)'
                                ],
                                borderColor: [
                                    'rgba(75, 192, 192, 1)',
                                    'rgba(255, 99, 132, 1)',
                                    'rgba(54, 162, 235, 1)'
                                ],
                                borderWidth: 1
                            }]
                        },
                        options: {
                            responsive: true,
                            scales: {
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }
                    });
                </script>
                
                <div class="products">
                <li class="menu-item"><i class="icon-products"></i><a href="{{ route('admin.products') }}">Products</a></li>
                    <table>
                        <tr>
                            <th>Products</th>
                            <th>Stok</th>
                        </tr>
                        <tr>
                            <td>Ikan Arwana</td>
                            <td>2</td>
                        </tr>
                        <tr>
                            <td>Aerator</td>
                            <td>0</td>
                        </tr>
                    </table>
                </div>
                
                <div class="shipment-schedule">
                    <li class="menu-item"><i class="icon-statistics"></i> <a href="{{ route('admin.delivery-schedules') }}">Jadwal Pengantaran</a> </li>
                    <table>
                        <tr>
                            <th>Products</th>
                            <th>Penerima</th>
                        </tr>
                        <tr>
                            <td>Ikan Arwana</td>
                            <td>Indah</td>
                        </tr>
                        <tr>
                            <td>Aerator</td>
                            <td>Maria</td>
                        </tr>
                    </table>
                    <p>Total Pengiriman: 2</p>
                </div>
                <div class="last-orders">
                    <h2>Last Orders</h2>
                    <table>
                        <tr>
                            <td>Hira</td>
                            <td>Rp.50.000</td>
                            <td>Completed</td>
                            <td>11/10/2024</td>
                        </tr>
                        <tr>
                            <td>Indah</td>
                            <td>Rp.100.000</td>
                            <td>Completed</td>
                            <td>08/10/2024</td>
                        </tr>
                    </table>
                    <a href="#" class="view-all">View All Orders</a>
                </div>
            </section>
        </main>
    </div>
   
</body>
</html>