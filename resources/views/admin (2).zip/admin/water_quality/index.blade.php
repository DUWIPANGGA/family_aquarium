<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monitoring Kualitas Air</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

    <!-- Menampilkan pesan jika ada session 'success' -->
    @if(session('success'))
        <div class="alert alert-success">
            <p>{{ session('success') }}</p> 
        </div>
    @endif

    <div class="container"> 
        <h1>Monitoring Air</h1>
        <a href="{{ route('admin.water_quality.create') }}" class="btn btn-success mb-3">Tambah Data</a>
    
        <table class="table table-bordered">
            <thead class="thead-light">
                <tr>
                    <th>ID</th>
                    <th>Aquarium</th>
                    <th>pH</th>
                    <th>Kekeruhan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <!-- Looping data untuk menampilkan setiap item -->
                @foreach($data as $item)
                    <tr>
                        <td>{{ $item->id }}</td>
                        <td>{{ $item->aquarium }}</td>
                        <td>{{ $item->pH }}</td>
                        <td>{{ $item->turbidity }}</td>
                        <td>
<!-- Print Button -->
                            <a href="{{ route('admin.water_quality.edit', $item->id) }}" class="btn btn-primary">Edit</a>
                            <form action="{{ route('admin.water_quality.destroy', $item->id) }}" method="POST" style="display:inline-block;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Delete</button>
                            </form>
                          
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        <button class="print-btn" onclick="window.print()">Cetak PDF</button>
</body>
</html>