<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Kualitas Air</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

    <div class="container mt-5">
        <h1>Tambah Data Kualitas Air</h1>
        
        <!-- Form untuk menambah data -->
        <form action="{{ route('admin.water_quality.store') }}" method="POST">
            @csrf
    
            <div class="form-group">
                <label for="aquarium">Aquarium</label>
                <input type="text" name="aquarium" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="ph">pH</label>
                <input type="number" name="pH" class="form-control" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="turbidity">Turbidity</label>
                <input type="number" name="turbidity" class="form-control" step="0.01" required>
            </div>
            <button type="submit" class="btn btn-success">Create Data</button>
        </form>

        <!-- Menampilkan Data Baru yang Tersimpan -->
        @if(session('newData'))
            <div class="alert alert-success mt-3">
                <h4>Data Berhasil Ditambahkan:</h4>
                <ul>
                    <li><strong>ID:</strong> {{ session('newData')['id'] }}</li>
                    <li><strong>Aquarium:</strong> {{ session('newData')['aquarium'] }}</li>
                    <li><strong>pH:</strong> {{ session('newData')['pH'] }}</li>
                    <li><strong>Turbidity:</strong> {{ session('newData')['turbidity'] }}</li>
                </ul>
            </div>
        @endif
    </div>

</body>
</html>
