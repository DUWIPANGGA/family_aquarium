<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Penjualan</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <h2 class="mb-4">Rekap Penjualan</h2>
    <a href="{{ route('admin.rekappenjualans.create') }}" class="btn btn-primary mb-3">Tambah Rekap</a>
    <table class="table table-bordered table-striped">
        <thead class="thead-dark">
            <tr>
                <th>Nomor Pesanan</th>
                <th>Tanggal</th>
                <th>Username Pembeli</th>
                <th>Kategori Produk</th>
                <th>Kode Barang</th>
                <th>Metode Pembayaran</th>
                <th>Jumlah Pembelian</th>
                <th>Total Harga</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($rekappenjualans as $rekap)
                <tr>
                    <td>{{ $rekap->nomor_pesanan }}</td>
                    <td>{{ $rekap->tanggal }}</td>
                    <td>{{ $rekap->username_pembeli }}</td>
                    <td>{{ $rekap->kategori_produk }}</td>
                    <td>{{ $rekap->kode_barang }}</td>
                    <td>{{ $rekap->metode_pembayaran }}</td>
                    <td>{{ $rekap->jumlah_pembelian }}</td>
                    <td>Rp{{ number_format($rekap->total_harga, 2, ',', '.') }}</td>
                    <td>
                        <a href="{{ route('admin.rekappenjualans.edit', $rekap->id) }}" class="btn btn-warning btn-sm">Edit</a>
                        <form action="{{ route('admin.rekappenjualans.destroy', $rekap->id) }}" method="POST" style="display:inline-block;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="9" class="text-center">Tidak ada data rekap penjualan.</td>
                </tr>
            @endforelse
        </tbody>
    </table>
</div>

</body>
</html>
