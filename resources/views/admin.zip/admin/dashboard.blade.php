<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Family Aquarium</title>
    <style>
        /* Container utama */
        .dashboard-container {
            display: flex;
            background-color: #f4f4f4;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background-color: #2c2c2c;
            color: #fff;
            padding: 20px;
        }

        .brand {
            color: #28a745;
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .menu {
            list-style: none;
            padding: 0;
        }

        .menu-item {
            color: #ffffff;
            padding: 10px;
            display: flex;
            align-items: center;
            cursor: pointer;
            transition: background 0.3s;
        }

        .menu-item.active, .menu-item:hover {
            background-color: #28a745;
        }

        /* Icon dalam menu sidebar */
        .menu-item i {
            margin-right: 10px;
        }

        /* Bagian utama konten */
        .content {
            flex: 1;
            padding: 20px;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            font-size: 24px;
            margin: 0;
        }

        .search {
            position: relative;
        }

        .search input {
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .search-btn {
            position: absolute;
            right: 5px;
            top: 5px;
            background: none;
            border: none;
            cursor: pointer;
        }

        .user-info {
            display: flex;
            align-items: center;
            color: #333;
        }

        /* Grid layout untuk konten utama */
        .main-content {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr;
            gap: 20px;
            margin-top: 20px;
        }

        /* Komponen dalam konten utama */
        .sales-progress, .products, .shipment-schedule, .last-orders {
            background-color: #e6e6e6;
            padding: 20px;
            border-radius: 8px;
        }

        h2 {
            font-size: 18px;
            margin-bottom: 10px;
        }

        /* Tabel */
        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .view-all {
            display: block;
            text-align: center;
            margin-top: 10px;
            text-decoration: none;
            color: #28a745;
        }

        .view-all:hover {
            color: #218838;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <h2 class="brand">FAMILY AQUARIUM</h2>
            <ul class="menu">
                <li class="menu-item active"><i class="icon-dashboard"></i> Dashboard</li>
                <li class="menu-item"><i class="icon-products"></i> Products</li>
                <li class="menu-item"><i class="icon-statistics"></i> Statistics</li>
                <li class="menu-item"><i class="icon-transactions"></i> Transactions</li>
                <li class="menu-item"><i class="icon-customers"></i> Customers</li>
                <li class="menu-item"><i class="icon-messages"></i> Messages</li>
                <li class="menu-item"><i class="icon-monitoring"></i> Monitoring Air</li>
                <li class="menu-item">
                    <a href="{{ route('admin.rekappenjualans.index') }}">
                        <i class="icon-rekap"></i> Rekap
                    </a>                    
                <li class="menu-item"><i class="icon-settings"></i> Settings</li>
                <li class="menu-item"><i class="icon-logout"></i> Log Out</li>
            </ul>
        </aside>
        <main class="content">
            <header class="header">
                <h1>DASHBOARD</h1>
                <p>Manajemen Penjualan</p>
                <div class="search">
                    <input type="text" placeholder="Search">
                    <button class="search-btn">🔍</button>
                </div>
                <div class="user-info">
                    <i class="icon-bell"></i> OWNER
                </div>
            </header>
            <section class="main-content">
                <div class="sales-progress">
                    <h2>Perkembangan penjualan</h2>
                    <!-- Tambahkan grafik penjualan di sini -->
                </div>
                <div class="products">
                    <h2>Products</h2>
                    <table>
                        <tr>
                            <th>Products</th>
                            <th>Stok</th>
                        </tr>
                        <tr>
                            <td>Ikan Arwana</td>
                            <td>2</td>
                        </tr>
                        <tr>
                            <td>Aerator</td>
                            <td>0</td>
                        </tr>
                    </table>
                </div>
                <div class="shipment-schedule">
                    <h2>Jadwal Pengiriman</h2>
                    <table>
                        <tr>
                            <th>Products</th>
                            <th>Penerima</th>
                        </tr>
                        <tr>
                            <td>Ikan Arwana</td>
                            <td>Indah</td>
                        </tr>
                        <tr>
                            <td>Aerator</td>
                            <td>Maria</td>
                        </tr>
                    </table>
                    <p>Total Pengiriman: 8</p>
                </div>
                <div class="last-orders">
                    <h2>Last Orders</h2>
                    <table>
                        <tr>
                            <td>Hira</td>
                            <td>Rp.50.000</td>
                            <td>Completed</td>
                            <td>11/10/2024</td>
                        </tr>
                        <tr>
                            <td>Indah</td>
                            <td>Rp.100.000</td>
                            <td>Completed</td>
                            <td>08/10/2024</td>
                        </tr>
                    </table>
                    <a href="#" class="view-all">View All Orders</a>
                </div>
            </section>
        </main>
    </div>
</body>
</html>
