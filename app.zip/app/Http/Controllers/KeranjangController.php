<?php
use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    // Menampilkan semua produk
    public function index()
    {
        $products = Product::all();
        return view('products.index', compact('products'));
    }

    // Menampilkan form untuk menambahkan produk baru
    public function create()
    {
        return view('products.create');
    }

    // Menyimpan data produk baru
    public function store(Request $request)
    {
        $request->validate([
            'nama_produk' => 'required',
            'harga' => 'required|numeric',
            'foto_produk' => 'image|mimes:jpeg,png,jpg|max:2048',
        ]);

        $product = new Product();
        $product->nama_produk = $request->nama_produk;
        $product->harga = $request->harga;
        $product->deskripsi = $request->deskripsi;

        if ($request->hasFile('foto_produk')) {
            $imagePath = $request->file('foto_produk')->store('images', 'public');
            $product->foto_produk = $imagePath;
        }

        $product->save();
        return redirect()->route('products.index')->with('success', 'Produk berhasil ditambahkan.');
    }

    // Menampilkan detail produk untuk diedit
    public function edit($id)
    {
        $product = Product::findOrFail($id);
        return view('products.edit', compact('product'));
    }

    // Mengupdate data produk
    public function update(Request $request, $id)
    {
        $request->validate([
            'nama_produk' => 'required',
            'harga' => 'required|numeric',
        ]);

        $product = Product::findOrFail($id);
        $product->nama_produk = $request->nama_produk;
        $product->harga = $request->harga;
        $product->deskripsi = $request->deskripsi;

        if ($request->hasFile('foto_produk')) {
            $imagePath = $request->file('foto_produk')->store('images', 'public');
            $product->foto_produk = $imagePath;
        }

        $product->save();
        return redirect()->route('products.index')->with('success', 'Produk berhasil diperbarui.');
    }

    // Menghapus produk
    public function destroy($id)
    {
        $product = Product::findOrFail($id);
        $product->delete();
        return redirect()->route('products.index')->with('success', 'Produk berhasil dihapus.');
    }
}

    public function tambah(Request $request) {
    $request->validate([
        'product_id' => 'required|integer',
        'price' => 'required|numeric',
    ]);

    // Logika untuk menambahkan produk ke keranjang
    // Misalnya, simpan ke session atau database

    return response()->json(['success' => true]);
}
