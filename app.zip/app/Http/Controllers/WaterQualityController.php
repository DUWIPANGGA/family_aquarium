<?php
namespace App\Http\Controllers;

use App\Models\WaterQuality;
use Illuminate\Http\Request;


class WaterQualityController extends Controller
{
    public function index()
    {
        // Ambil semua data dari tabel water_quality
        $data = WaterQuality::all();
        
        // Kirim data ke view 'admin.water_quality.index'
        return view('admin.water_quality.index', compact('data'));
    }
    
    public function create()
    {
        // Arahkan ke halaman create
        return view('admin.water_quality.create');
    }

    public function store(Request $request)
    {
        // Validasi input dari user
        $request->validate([
            'aquarium' => 'required|string|max:255', // Validasi Aquarium
            'pH' => 'required|numeric|min:0|max:14', // Validasi pH
            'turbidity' => 'required|numeric|min:0', // Validasi Turbidity
        ]);
        
        // Menyimpan data ke dalam database dan mendapatkan objek yang baru dibuat
        $waterQuality = WaterQuality::create([
            'id' => $request->id,  // Pastikan ID ada
            'aquarium' => $request->aquarium,
            'pH' => $request->pH,
            'turbidity' => $request->turbidity,
        ]);
    
        // Redirect ke halaman yang menampilkan data baru
        return redirect()->route('admin.water_quality.index')
                         ->with('success', 'Data berhasil ditambahkan.')
                         ->with('newData', $waterQuality); // Mengirimkan data yang baru ditambahkan
    }
    
    
public function update(Request $request, $id)
{
    $request->validate([
        'pH' => 'required|numeric|min:0|max:14', // Validasi pH untuk rentang 0-14
        'turbidity' => 'required|numeric|min:0', // Validasi Kekeruhan minimum 0
    ]);

    $waterQuality = WaterQuality::findOrFail($id);
    $waterQuality->update([
        'pH' => $request->pH,
        'turbidity' => $request->turbidity,
    ]);

    return redirect()->route('admin.water_quality.index')->with('success', 'Data berhasil diperbarui.');
}

public function edit($id)
{
    // Ambil data berdasarkan ID
    $waterQuality = WaterQuality::findOrFail($id);

    // Kirim data ke view edit
    return view('admin.water_quality.edit', compact('waterQuality'));
}


    public function destroy($id)
    {
        $waterQuality = WaterQuality::findOrFail($id);
        $waterQuality->delete();

        return redirect()->route('admin.water_quality.index')->with('success', 'Data berhasil dihapus.');
    }

    public function exportPdf()
{
    $data = WaterQuality::all();  // Ambil data yang ingin ditampilkan dalam PDF
    $pdf = WaterQuality::loadView('admin.water_quality_pdf', ['data' => $data]);  // Men-load view dengan data
    return $pdf->download('admin.water_quality_report.pdf');  // Mendownload PDF
}
}