<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
        }
        .profil-header {
            text-align: center;
            margin-bottom: 20px;
        }
        .profil-header img {
            border-radius: 50%;
            width: 100px;
            height: 100px;
            object-fit: cover;
            cursor: pointer;
            border: 2px solid #28a745;
        }
        .profil-header p {
            font-size: 14px;
            color: #555;
        }
        .profil-header .edit-icon, .profil-header .check-icon {
            font-size: 24px;
            cursor: pointer;
            margin-top: 10px;
        }
        .profil-info h2 {
            font-size: 24px;
            text-align: center;
            color: #333;
        }
        .profil-fields {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }
        .profil-field {
            background-color: #28a745;
            color: #ffffff;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
        }
        .icons {
            display: flex;
            justify-content: space-around;
            padding: 20px;
            background-color: rgba(0, 0, 0, 0.5);
        }
        .icons a {
            color: white;
            font-size: 30px;
            padding: 15px;
            border-radius: 50%;
            background-color: white;
            transition: background-color 0.3s ease;
        }
        .icons a:hover {
            background-color: #28a745;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Profil Header -->
        <div class="profil-header">
            <img src="default-profil.png" alt="Profil Picture" id="profilPicture">
            <input type="file" id="fileInput" accept="image/*" style="display: none;">
            <p>Edit</p>
            <script>
                const profilPicture = document.getElementById("profilPicture");
                const fileInput = document.getElementById("fileInput");

                profilPicture.addEventListener("click", () => {
                    fileInput.click();
                });

                fileInput.addEventListener("change", (event) => {
                    const file = event.target.files[0];
                    if (file) {
                        const reader = new FileReader();
                        reader.onload = (e) => {
                            profilPicture.src = e.target.result;
                        };
                        reader.readAsDataURL(file);
                    }
                });
            </script>
            <i class="fas fa-check-circle check-icon"></i>
        </div>

        <!-- Profil Info -->
        <div class="profil-info">
            <h2>My Profile</h2>
        </div>

        <!-- Profil Fields (Read-only) -->
        <div class="profil-fields">
            <div class="profil-field">Nama: {{ $user->name ?? 'John Doe' }}</div>
            <div class="profil-field">No. Telepon: {{ $user->phone ?? '081234567890' }}</div>
            <div class="profil-field">Alamat Rumah: {{ $user->address ?? 'Jl. Contoh No. 123' }}</div>
            <div class="profil-field">Alamat Email: {{ $user->email ?? 'john.doe@example.com' }}</div>
        </div>
    </div>

    <!-- Bottom Menu -->
    <div class="icons">
        <a href="{{ route('home') }}"><i class="fas fa-home"></i></a>
        <a href="{{ route('cart') }}"><i class="fas fa-shopping-cart"></i></a>
        <a href="{{ route('profil') }}"><i class="fas fa-user"></i></a>
    </div>
</body>
</html>
