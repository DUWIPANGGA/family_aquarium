<?php
// App/Models/Product.php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model {
    // Nama tabel yang akan digunakan oleh model ini
    protected $table = 'products';

    // Atribut yang dapat diisi secara massal
    protected $fillable = [
        'name', 'description', 'price'
    ];

    // Mengaktifkan timestamps (created_at dan updated_at)
    public $timestamps = true;
}