<?php

use App\Http\Controllers\ProfilController;
use App\Http\Middleware\Admin;
use App\Http\Controllers\CartController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\KeranjangController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\LandingPageController;
use App\Http\Controllers\RekapPenjualanController;
use App\Http\Controllers\DeliveryScheduleController;
use App\Http\Controllers\WaterQualityController;
use App\Http\Middleware\AdminMiddleware;
use Illuminate\Support\Facades\Route;

// Rute untuk landing page
Route::get('/', function () {
    return view('welcome');
});

// Rute untuk halaman umum
Route::get('/home', function () {
    return view('home');
})->name('home');

Route::get('/about', function () {
    return view('about');
});

Route::get('/toko', function () {
    return view('toko');
})->name('toko');

Route::get('/pakan', function () {
    return view('pakan');
})->name('pakan');

Route::get('/alat', function () {
    return view('alat');
})->name('alat');

Route::get('/kontak', function () {
    return view('kontak');
});

Route::get('/logout', function () {
    return view('logout');
});

Route::get('/keranjang', function () {
    return view('keranjang');
})->name('keranjang');

Route::get('/rekap', function () {
    return view('rekap');
})->name('rekap');

Route::get('/checkout', function () {
    return view('checkout');
})->name('checkout');

Route::get('/detailProduk', function () {
    return view('detailProduk');
})->name('detailProduk');

// Rute untuk dashboard yang dilindungi
Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

// Rute untuk rekap penjualan
Route::middleware('auth')->group(function () {
    Route::post('/keranjang/tambah', [KeranjangController::class, 'tambah'])->name('keranjang.tambah');

    Route::get('/profil', function () {
        return view('profil');
    })->name('profil');

    Route::get('/profil/edit', [ProfilController::class, 'edit'])->name('profil.edit');
    Route::post('/profil/update', [ProfilController::class, 'update'])->name('profil.update');
    Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
});

// Rute untuk admin
Route::middleware([Admin::class])->group(function () {
    Route::get('/admin/dashboard', [HomeController::class, 'index'])->name('admin.dashboard');
});
// Rute untuk admin
Route::middleware([Admin::class])->group(function () {
    Route::get('/admin/dashboard', [HomeController::class, 'index'])->name('admin.dashboard');
    Route::get('/admin/products', [ProductController::class, 'index'])->name('admin.products'); // Menampilkan daftar produk
    Route::get('/admin/products/create', [ProductController::class, 'create'])->name('admin.products.create'); // Menampilkan form untuk membuat produk
    Route::post('/admin/products/save', [ProductController::class, 'save'])->name('admin.products.save');
});

// Rute untuk produk
Route::get('/admin/products', [ProductController::class, 'index'])->name('admin.products');
// Route::get('/admin/products/create', [ProductController::class, 'create'])->name('admin.products.create');
Route::post('/admin/products/store', [ProductController::class, 'store'])->name('admin.products.store');
Route::get('/admin/products/edit/{id}', [ProductController::class, 'edit'])->name('admin.products.edit');
Route::get('/admin/products/{id}', [ProductController::class, 'show'])->name('admin.products.show');
Route::put('/admin/products/update/{id}', [ProductController::class, 'update'])->name('admin.products.update');
Route::delete('/admin/products/{id}', [ProductController::class, 'destroy'])->name('admin.products.destroy');

// Rute untuk jadwal pengantaran
Route::get('/admin/delivery-schedules', [DeliveryScheduleController::class, 'index'])->name('admin.delivery-schedules');
Route::get('/admin/delivery-schedules/create', [DeliveryScheduleController::class, 'create'])->name('admin.delivery-schedules.create');
Route::post('/admin/delivery-schedules/store', [DeliveryScheduleController::class, 'store'])->name('admin.delivery-schedules.store');
Route::get('/admin/delivery-schedules/edit/{id}', [DeliveryScheduleController::class, 'edit'])->name('admin.delivery-schedules.edit');
Route::get('/admin/delivery-schedules/{id}', [DeliveryScheduleController::class, 'show'])->name('admin.delivery-schedules.show');
Route::put('/admin/delivery-schedules/update/{id}', [DeliveryScheduleController::class, 'update'])->name('admin.delivery-schedules.update');
Route::delete('/admin/delivery-schedules/{id}', [DeliveryScheduleController::class, 'destroy'])->name('admin.delivery-schedules.destroy');

// Rute untuk kualitas air (admin)
// Rute untuk kualitas air (admin)
Route::prefix('admin')->name('admin.')->middleware('auth')->group(function () {
    Route::resource('water_quality', WaterQualityController::class);
    Route::get('admin/water_quality/{id}/edit', [WaterQualityController::class, 'edit'])->name('admin.water_quality.edit');
    Route::put('admin/water_quality/{id}', [WaterQualityController::class, 'update'])->name('admin.water_quality.update');
    Route::delete('admin/water_quality/{id}', [WaterQualityController::class, 'destroy'])->name('admin.water_quality.destroy');
    Route::get('admin/water_quality', [WaterQualityController::class, 'index'])->name('admin.water_quality.index');
    Route::resource('admin/water_quality', WaterQualityController::class);
    Route::get('admin.water_quality/create', [WaterQualityController::class, 'create'])->name('admin.water_quality.create');
    Route::post('admin.water_quality', [WaterQualityController::class, 'store'])->name('admin.water_quality.store');
    Route::get('admin/water_quality/export-pdf', [WaterQualityController::class, 'exportPdf'])->name('admin.water_quality.export_pdf');
    Route::get('/admin/water_quality', [WaterQualityController::class, 'index']);
});

// Menambahkan route resource dan menyesuaikan dengan kebutuhan
Route::resource('rekappenjualans', RekapPenjualanController::class)->names([
    'index' => 'admin.rekappenjualans.index',
    'create' => 'admin.rekappenjualans.create',
    'store' => 'admin.rekappenjualans.store',
    'edit' => 'admin.rekappenjualans.edit',
    'update' => 'admin.rekappenjualans.update',
    'destroy' => 'admin.rekappenjualans.destroy',
])
    ->except(['show']); // Menghilangkan show karena kita akan membuat route custom

// Menambahkan route show khusus untuk menampilkan semua Rekap Penjualan
Route::get('admin/rekappenjualans/show', [RekapPenjualanController::class, 'showAll'])->name('admin.rekappenjualans.showAll');

Route::get('rekappenjualans/cetak', [RekapPenjualanController::class, 'cetak'])->name('admin.rekappenjualans.cetak');

// Rute tambahan untuk fitur cetak
Route::get('rekap/cetak', [RekapPenjualanController::class, 'cetak'])->name('admin.rekap.cetak');

// Rute untuk landing page
Route::get('/landing', [LandingPageController::class, 'show']);

// Memuat rute autentikasi
require __DIR__ . '/auth.php';
