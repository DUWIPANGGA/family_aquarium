<?php

use App\Http\Controllers\API\Auth\AuthController;
use App\Http\Controllers\API\RekapPenjualanController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

//login api
Route::post('login', [AuthController::class, 'login']);

//api rekap/penjualan required login
Route::group(['middleware' => 'auth:sanctum'], function () {
    Route::get('/rekap-penjualan', [RekapPenjualanController::class, 'getRekapPenjualan']);
});
